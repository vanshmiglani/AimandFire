from directKeys import *
from calculator import calculate_distance  # Import from utils.py
mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils
def aim_and_fire(results, frame):
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            middle_finger_tip = hand_landmarks.landmark[mp_hands.HandLandmark.MIDDLE_FINGER_TIP]
            thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP]

            dif = calculate_distance(middle_finger_tip, thumb_tip)
            if dif <= 0.24:
                PressKey(X)
                print('🎯 Aim Started')
                if dif >= 0.10 and dif <= 0.155:
                    PressKey(X)
                    PressKey(I)
                    print('🏹 Shoot the person')
                else:
                    ReleaseKey(I)
                    print('↵ Back to Aiming')

            else:
                ReleaseKey(X)
                ReleaseKey(I)
                print('C.P.U gonna relief')
