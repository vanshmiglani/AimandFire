import cv2
import mediapipe as mp
import pyautogui
from mousemovement import move_mouse
from AimFire import aim_and_fire

# Camera initialization
cap = cv2.VideoCapture(0)  
cap.set(3, 640)  # Set width
cap.set(4, 480)  # Set height
cap.set(cv2.CAP_PROP_FPS, 60)

# Initialize Mediapipe Hand Detection
mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)

# Variables for tracking previous positions
prev_x, prev_y = 0, 0
initialized = False
sensitivity = 15.0  # Adjust this if needed

# Get screen width for right hand movement detection
screen_width, _ = pyautogui.size()

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)  # Flip for mirror effect
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb_frame)

    if results.multi_hand_landmarks:
        left_hand = None
        right_hand = None

        for hand_landmarks in results.multi_hand_landmarks:
            hand_x = hand_landmarks.landmark[mp_hands.HandLandmark.WRIST].x
            
            # Determine left or right hand
            if hand_x < 0.5:
                left_hand = hand_landmarks
            else:
                right_hand = hand_landmarks
            
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        # Pass the results and frame to mouse and aiming logic
        if left_hand:
            aim_and_fire(results, frame)  # Call the aiming logic with the necessary arguments

        if right_hand:
            move_mouse(results, frame)  # Call the mouse movement logic with the necessary arguments

    cv2.imshow("Accessing GTA V", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):  
        break

cap.release()
cv2.destroyAllWindows()
