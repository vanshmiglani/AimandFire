from directKeys import *
from calculator import calculate_distance  # Import from utils.py

# Declare initialized globally
initialized = False
prev_x, prev_y = 0, 0
sensitivity = 15.0  # Adjust this if needed

def move_mouse(results, frame):
    global initialized, prev_x, prev_y  # Declare them as global
    
    if results.multi_hand_landmarks:
        hand_landmarks = results.multi_hand_landmarks[0]
        x = hand_landmarks.landmark[8].x
        y = hand_landmarks.landmark[8].y

        # Convert to screen pixels
        screen = screeninfo.get_monitors()[0]
        screen_width, screen_height = screen.width, screen.height
        curr_x = int(x * screen_width)
        curr_y = int(y * screen_height)

        if not initialized:
            prev_x, prev_y = curr_x, curr_y
            initialized = True

        dx = (curr_x - prev_x) * sensitivity
        dy = (curr_y - prev_y) * sensitivity

        # Amplify for quick flicks
        dx = amplify(dx)
        dy = amplify(dy)

        # Optional clamp to avoid camera spin-out
        dx = max(-80, min(80, dx))
        dy = max(-80, min(80, dy))

        move_mouse_rel(dx, dy)

        prev_x, prev_y = curr_x, curr_y
